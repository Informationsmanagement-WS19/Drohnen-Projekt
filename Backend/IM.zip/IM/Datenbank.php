<?php
$db = new mysqli('localhost','TestUser', 'root', 'drohnenProjekt');
$erg = $db->query("Select * from flugdaten") or die($db->error);
if($erg->num_rows){
  '\n'  ;
  echo " </br>" ." </br>" ." </br>" ." </br>" ." </br>" ." </br>" ." </br>" ." </br>" ." </br>";
  echo " <p>  Datenvorhanden: Anzahl ";
  echo $erg->num_rows;
}
$datensatz = $erg->fetch_all(MYSQLI_ASSOC);
foreach($datensatz as $zeile) {
  echo '<br>';
  echo '<br> ' . "Nr " . $zeile['Nr'] ;
  echo '<br> ' . "Breitengrad " . $zeile['Breitengrad'] ;
  echo '<br> ' . "Längengrad " . $zeile['Laengengrad'] ;
  echo '<br> ' . "Hoehe " . $zeile['Hoehe'] ;
  echo '<br> ' . "Kameraposition " . $zeile['Kameraposition'] ;
}
  ?>
